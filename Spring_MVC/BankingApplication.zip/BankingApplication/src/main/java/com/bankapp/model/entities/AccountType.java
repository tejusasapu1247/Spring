package com.bankapp.model.entities;

public enum AccountType {
	SAVING,CURRENT;
}
