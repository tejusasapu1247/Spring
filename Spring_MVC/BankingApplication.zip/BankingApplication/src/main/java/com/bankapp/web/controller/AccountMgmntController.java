package com.bankapp.web.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import com.bankapp.model.service.AccountService;
import com.bankapp.web.formbeans.Transferbean;

@Controller
public class AccountMgmntController {
	
	private AccountService accountService;
	
	@Autowired
	public AccountMgmntController(AccountService accountService) {
		this.accountService = accountService;
	}
	
	@GetMapping("/")
	public String entry() {
		return "redirect:/home";
	}

	@GetMapping("home")
	public String home() {
		return "home";
	}
	

	@GetMapping("success")
	public String success() {
		return "success";
	}
	
	@GetMapping("transfer")
	public String tranferAmountGet(ModelMap mv) {
		mv.addAttribute("transferbean", new Transferbean());
		return "transfer";
	}
	@PostMapping("transfer")
	public String tranferAmountPost(@ModelAttribute(name="transferbean") Transferbean transferBean) {
		int fromAcc=transferBean.getFromAccountId();
		int toAcc=transferBean.getToAccountId();
		double amount=transferBean.getAmount();
		accountService.tranfer(fromAcc, toAcc, amount);
		return "redirect:/success";
	}

	
}
