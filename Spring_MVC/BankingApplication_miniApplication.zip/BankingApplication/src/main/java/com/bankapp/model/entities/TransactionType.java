package com.bankapp.model.entities;

public enum TransactionType {
	WITHDRAW, DEPOSIT, TRANSFER;
}
