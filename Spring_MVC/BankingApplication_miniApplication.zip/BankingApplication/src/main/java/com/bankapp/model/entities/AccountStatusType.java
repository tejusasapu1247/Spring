package com.bankapp.model.entities;

public enum AccountStatusType {
	ACTIVE,SUSPEND,CLOSED;
}
