package com.bookapp.model.dao;

@SuppressWarnings("serial")
public class BookNotFoundException extends RuntimeException{

	public BookNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
