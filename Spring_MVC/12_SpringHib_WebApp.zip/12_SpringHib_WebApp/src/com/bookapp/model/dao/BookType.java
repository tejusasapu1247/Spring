package com.bookapp.model.dao;

public enum BookType {
	
	IT, MGT, LifeSkill;

}
