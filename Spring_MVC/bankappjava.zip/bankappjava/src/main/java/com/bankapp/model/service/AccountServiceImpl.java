package com.bankapp.model.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bankapp.model.dao.Account;
import com.bankapp.model.dao.AccountDao;
import com.bankapp.model.service.aspects.Loggable;

@Service(value = "as")
@Transactional
public class AccountServiceImpl implements AccountService {

	private AccountDao dao;

	private EmailService emailService;

	@Autowired
	public void setEmailService(EmailService emailService) {
		this.emailService = emailService;
	}

	public AccountServiceImpl() {
	}

	@Autowired
	public AccountServiceImpl(AccountDao dao) {
		this.dao = dao;
	}

	public void setDao(AccountDao dao) {
		this.dao = dao;
	}

	@Override
	public Account getAccountById(int id) {
		Account account= dao.getAccountById(id);
		if(account==null)
			throw new AccountNotFoundException("account with id "+ id +" is not found");
		return  account;

	}

	@Override
	public Account addAccount(Account account) {
		return dao.addAccount(account);
	}

	@Loggable
	@Override
	public void transfer(int fromId, int toId, double amount) {
		Account fromAcc = getAccountById(fromId);
		Account toAcc = getAccountById(toId);
		fromAcc.setBalance(fromAcc.getBalance() - amount);
		toAcc.setBalance(toAcc.getBalance() + amount);

		dao.updateAccount(fromAcc);
		dao.updateAccount(toAcc);

		try {
			Thread.sleep(1000);
		}catch(InterruptedException ex) {}
		if (emailService != null) {
			emailService.sendEmail("r@r.com");
		}
	}

	@Override
	public void withdraw(int accountId, double amount) {
		Account account=getAccountById(accountId);
		account.setBalance(account.getBalance()- amount);
		dao.updateAccount(account);
	}
	

	@Override
	public void deposit(int accountId, double amount) {
		Account account=getAccountById(accountId);
		account.setBalance(account.getBalance()+ amount);
		dao.updateAccount(account);
	}

	@Override
	public void updateAddressDetails(int accountId, String address, String email, String phone) {
		Account account=getAccountById(accountId);
		account.setAddress(address);
		account.setEmail(email);
		account.setPhone(phone);
		dao.updateAccount(account);
	}
	

}
