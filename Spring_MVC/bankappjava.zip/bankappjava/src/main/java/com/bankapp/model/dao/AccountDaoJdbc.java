package com.bankapp.model.dao;

import org.springframework.stereotype.Repository;

@Repository
public class AccountDaoJdbc implements AccountDao{

	@Override
	public Account getAccountById(int id) {
		System.out.println("jdbc imp is called....");
		return new Account(id, "raj", 5000.0);
	}

	@Override
	public Account addAccount(Account account) {
		
		return null;
	}

	@Override
	public Account updateAccount(Account account) {
		return null;
	}

}
