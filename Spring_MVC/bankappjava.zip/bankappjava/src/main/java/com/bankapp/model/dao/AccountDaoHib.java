package com.bankapp.model.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;
@Primary
@Repository
public class AccountDaoHib implements AccountDao{

	private SessionFactory sessionFactory;
	
	@Autowired
	public AccountDaoHib(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	private Session getSession() {
		return sessionFactory.getCurrentSession();
	}
	public Account addAccount(Account account) {
		getSession().persist(account);
		return account;
	}
	@Override
	public Account getAccountById(int id) {
		return getSession().find(Account.class, id);
	}
	@Override
	public Account updateAccount(Account account) {
		getSession().merge(account);
		return account;
	}
	

}
