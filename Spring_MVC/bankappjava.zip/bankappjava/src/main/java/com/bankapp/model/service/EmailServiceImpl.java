package com.bankapp.model.service;

import org.springframework.stereotype.Service;

@Service
public class EmailServiceImpl implements EmailService {

	@Override
	public boolean sendEmail(String name) {
		System.out.println("email was send to person named: "+ name);
		return true;
	}

}
