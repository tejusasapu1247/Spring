package com.bankapp.web;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bankapp.config.ModelConfig;
import com.bankapp.model.dao.Account;
import com.bankapp.model.service.AccountService;

public class Main {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext ctx=
				new AnnotationConfigApplicationContext(ModelConfig.class);
		
	//	ApplicationContext ctx=new ClassPathXmlApplicationContext("accounts.xml");
		AccountService accountService=ctx.getBean("as", AccountService.class);
		
		//Account account1=new Account("raj", 5000.00, "delhi", "raj@r.com", "6454545455");
		//Account account2=new Account("ekta", 5000.00, "delhi", "ekta@r.com", "6454545455");
		
		//accountService.addAccount(account1);
		//accountService.addAccount(account2);
		
		//accountService.transfer(1, 2, 10);
		
		//accountService.deposit(1, 10);
		//accountService.withdraw(2, 10);
		
		accountService.updateAddressDetails(1, "banglore", "r@r.com", "9958543978");
	
	}
}
