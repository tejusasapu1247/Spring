package com.bankapp.model.service;

public interface EmailService {
	public boolean sendEmail(String name);
}
