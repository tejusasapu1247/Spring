package com.bankapp.config;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;
import org.springframework.web.servlet.FrameworkServlet;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

public class AppInit extends AbstractAnnotationConfigDispatcherServletInitializer {

	//this method is used to register the bean in root app context
	@Override
	protected Class<?>[] getRootConfigClasses() {
		System.out.println("this method is used to register the bean in root app context");
		return new Class[] {ModelConfig.class};
	}

	//this method is used to register the bean in web app context
	@Override
	protected Class<?>[] getServletConfigClasses() {
		System.out.println("this method is used to register the bean in web app context");
		return new Class[] {WebConfig.class};
	}

	@Override
	protected String[] getServletMappings() {
		return new String[] {"/"};
	}

	//handle exception in spring mvc: java config way
	@Override
	protected FrameworkServlet createDispatcherServlet(WebApplicationContext servletAppContext) {
		DispatcherServlet ds=new DispatcherServlet(servletAppContext);
		ds.setThrowExceptionIfNoHandlerFound(true);
		return ds;
	}
	
	

}
