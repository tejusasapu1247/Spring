package com.bankapp.model.service;

import com.bankapp.model.dao.Account;

public interface AccountService {
	public Account getAccountById(int id);
	public Account addAccount(Account account);
	public void deposit(int accountId, double amount);
	public void withdraw(int accountId, double amount);
	public void updateAddressDetails(int accountId, String address, String email, String phone);
	public void transfer(int fromId, int toId, double amount);
}
