package com.bankapp.model.service;

public class AccountNotFoundException extends RuntimeException{
	private static final long serialVersionUID = 1L;

	public AccountNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
