package com.bankapp.model.dao;

public interface AccountDao {
	public Account getAccountById(int id);
	public Account updateAccount(Account account);
	public Account addAccount(Account account);
	
}
